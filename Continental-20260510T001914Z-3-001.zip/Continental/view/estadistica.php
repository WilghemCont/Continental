<?php
require_once("../models/donaciones.php");
$modelDonacion = new DonacionModel();

$total_recaudado = $modelDonacion->obtenerSumaTotal();
$datosMetodos    = $modelDonacion->obtenerTotalesPorMetodo();
$comisiones      = $modelDonacion->obtenerComisionesPorCaso();

$metodos = [];
$montos  = [];

foreach ($datosMetodos as $dm) {
    $metodos[] = $dm['metodo'];
    $montos[]  = $dm['total'];
}

// Totales de comisiones
$totalComisiones  = array_sum(array_column($comisiones, 'comision'));
$totalDonaciones  = array_sum(array_column($comisiones, 'total_donado'));

require_once 'layout/header.php';
?>

<div class="container py-5 fade-up">
    <div class="row align-items-center mb-5">
        <div class="col-md-7">
            <h2 class="about-title mb-1">Impacto de Donaciones</h2>
            <p class="about-text">Visualiza cómo la comunidad está aportando a las causas sociales.</p>
        </div>
        <div class="col-md-5">
            <div class="stat-card text-center text-white border-0 shadow-lg" style="background: var(--grad); border-radius: 20px;">
                <p class="small mb-1 opacity-75 fw-bold text-uppercase">Total Recaudado</p>
                <div class="stat-num" style="font-size: 3rem;">S/ <?php echo number_format($total_recaudado, 2); ?></div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm p-4 h-100" style="border-radius: 18px;">
                <h5 class="fw-bold mb-4" style="color: var(--dark);">📊 Donaciones por Método de Pago</h5>
                <div style="min-height: 350px;">
                    <canvas id="graficoDonar"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-4 h-100" style="border-radius: 18px;">
                <h6 class="fw-bold mb-4 text-muted">Desglose de Aportes</h6>
                <div class="table-responsive">
                    <table class="table table-borderless align-middle">
                        <tbody>
                            <?php foreach($datosMetodos as $d): ?>
                            <tr>
                                <td class="ps-0">
                                    <div class="d-flex align-items-center">
                                        <div class="me-2" style="width:12px; height:12px; border-radius:50%; background: var(--verde);"></div>
                                        <span class="small fw-bold"><?php echo $d['metodo']; ?></span>
                                    </div>
                                </td>
                                <td class="text-end pe-0 fw-bold text-primary">S/ <?php echo number_format($d['total'], 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-auto p-3 bg-light rounded-3 text-center">
                    <p class="small text-muted mb-0">Gracias por ser parte del cambio 💙</p>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- ── Sección: Comisiones por Casos ─────────────────────────── -->
    <div class="row align-items-center mt-5 mb-4">
        <div class="col-md-7">
            <h2 class="about-title mb-1">Comisiones por Casos</h2>
            <p class="about-text">Ingresos generados por casos sociales activos mediante donaciones procesadas en la plataforma.</p>
        </div>
        <div class="col-md-5">
            <div class="card border-0 shadow-sm p-3" style="border-radius:18px; background:var(--grad);">
                <div class="row g-2 text-white text-center">
                    <div class="col-6">
                        <p class="small mb-1 opacity-75 fw-bold text-uppercase">Total Donado</p>
                        <div class="fw-bold fs-4">S/ <?php echo number_format($totalDonaciones, 2); ?></div>
                    </div>
                    <div class="col-6">
                        <p class="small mb-1 opacity-75 fw-bold text-uppercase">Total Comisiones</p>
                        <div class="fw-bold fs-4">S/ <?php echo number_format($totalComisiones, 2); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Nota explicativa de porcentajes -->
    <div class="alert border-0 shadow-sm mb-4 d-flex align-items-start gap-3" style="border-radius:14px; background:#eff6ff;">
        <i class="bi bi-info-circle-fill text-primary fs-5 mt-1"></i>
        <div>
            <strong>Cálculo automático de comisiones:</strong>
            Las comisiones se aplican al momento de procesar cada donación mediante MercadoPago.
            El porcentaje es del <strong>3 %</strong> para montos hasta S/ 10,000
            y del <strong>5 %</strong> para montos superiores.
        </div>
    </div>

    <div class="row g-4 mb-5">
        <!-- Gráfico de barras por método -->
        <div class="col-md-7">
            <div class="card border-0 shadow-sm p-4 h-100" style="border-radius:18px;">
                <h5 class="fw-bold mb-4" style="color:var(--dark);">📈 Donado vs Comisión por Donante</h5>
                <div style="min-height:320px;">
                    <canvas id="graficoComisiones"></canvas>
                </div>
            </div>
        </div>

        <!-- Tabla detalle -->
        <div class="col-md-5">
            <div class="card border-0 shadow-sm p-4 h-100" style="border-radius:18px;">
                <h6 class="fw-bold mb-3 text-muted">Detalle por Donante</h6>
                <div class="table-responsive">
                    <table class="table table-borderless align-middle small">
                        <thead>
                            <tr class="text-muted">
                                <th class="ps-0">Donante</th>
                                <th class="text-end">Donado</th>
                                <th class="text-end">Comisión</th>
                                <th class="text-end">%</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($comisiones as $c): ?>
                            <tr>
                                <td class="ps-0 fw-semibold"><?php echo htmlspecialchars($c['nombre']); ?></td>
                                <td class="text-end">S/ <?php echo number_format($c['total_donado'], 2); ?></td>
                                <td class="text-end text-success fw-bold">S/ <?php echo number_format($c['comision'], 2); ?></td>
                                <td class="text-end">
                                    <span class="badge bg-<?php echo $c['porcentaje'] >= 5 ? 'warning text-dark' : 'info text-dark'; ?>">
                                        <?php echo $c['porcentaje']; ?>%
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($comisiones)): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">
                                    <i class="bi bi-inbox d-block fs-3 mb-2 opacity-50"></i>
                                    Sin donaciones registradas
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('graficoDonar').getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($metodos); ?>,
            datasets: [{
                data: <?php echo json_encode($montos); ?>,
                backgroundColor: [
                    '#2a7ab5', // Azul SocialFunding
                    '#3a9e6f', // Verde SocialFunding
                    '#1a5a8a', // Variación Azul
                    '#e8f3fb', // Azul Light
                    '#256b4a'  // Verde Dark
                ],
                hoverOffset: 20,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 25,
                        usePointStyle: true,
                        font: { family: 'DM Sans', size: 13 }
                    }
                }
            },
            cutout: '65%' // Estilo moderno de anillo
        }
    });
});

    // ── Gráfico de comisiones por donante ────────────────────────
    const ctxCom = document.getElementById('graficoComisiones');
    if (ctxCom) {
        const nombresC  = <?php echo json_encode(array_column($comisiones, 'nombre')); ?>;
        const donadoC   = <?php echo json_encode(array_map('floatval', array_column($comisiones, 'total_donado'))); ?>;
        const comisionC = <?php echo json_encode(array_map('floatval', array_column($comisiones, 'comision'))); ?>;

        new Chart(ctxCom.getContext('2d'), {
            type: 'bar',
            data: {
                labels: nombresC,
                datasets: [
                    {
                        label: 'Total Donado',
                        data: donadoC,
                        backgroundColor: '#2a7ab5',
                        borderRadius: 6
                    },
                    {
                        label: 'Comisión Plataforma',
                        data: comisionC,
                        backgroundColor: '#3a9e6f',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { font: { family: 'DM Sans', size: 12 }, padding: 20, usePointStyle: true }
                    },
                    tooltip: {
                        callbacks: {
                            label: ctx => ' S/ ' + ctx.parsed.y.toLocaleString('es-PE', {minimumFractionDigits: 2})
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: v => 'S/ ' + v.toLocaleString('es-PE')
                        }
                    }
                }
            }
        });
    }
});
</script>

<?php require_once 'layout/footer.php'; ?>